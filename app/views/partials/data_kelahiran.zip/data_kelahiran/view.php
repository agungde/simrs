<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("data_kelahiran/add");
$can_edit = ACL::is_allowed("data_kelahiran/edit");
$can_view = ACL::is_allowed("data_kelahiran/view");
$can_delete = ACL::is_allowed("data_kelahiran/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">View  Data Kelahiran</h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="card animated fadeIn page-content">
                        <?php
                        $counter = 0;
                        if(!empty($data)){
                        $rec_id = (!empty($data['id']) ? urlencode($data['id']) : null);
                        $counter++;
                        ?>
                        <div id="page-report-body" class="">
                            <table class="table table-hover table-borderless table-striped">
                                <!-- Table Body Start -->
                                <tbody class="page-data" id="page-data-<?php echo $page_element_id; ?>">
                                    <tr  class="td-id">
                                        <th class="title"> Id: </th>
                                        <td class="value"> <?php echo $data['id']; ?></td>
                                    </tr>
                                    <tr  class="td-id_ranap_bersalin">
                                        <th class="title"> Id Ranap Bersalin: </th>
                                        <td class="value"> <?php echo $data['id_ranap_bersalin']; ?></td>
                                    </tr>
                                    <tr  class="td-tanggal">
                                        <th class="title"> Tanggal: </th>
                                        <td class="value"> <?php echo $data['tanggal']; ?></td>
                                    </tr>
                                    <tr  class="td-jam">
                                        <th class="title"> Jam: </th>
                                        <td class="value"> <?php echo $data['jam']; ?></td>
                                    </tr>
                                    <tr  class="td-jenis_kelamin">
                                        <th class="title"> Jenis Kelamin: </th>
                                        <td class="value"> <?php echo $data['jenis_kelamin']; ?></td>
                                    </tr>
                                    <tr  class="td-Jenis_kelahiran">
                                        <th class="title"> Jenis Kelahiran: </th>
                                        <td class="value"> <?php echo $data['Jenis_kelahiran']; ?></td>
                                    </tr>
                                    <tr  class="td-kelahiran_ke">
                                        <th class="title"> Kelahiran Ke: </th>
                                        <td class="value"> <?php echo $data['kelahiran_ke']; ?></td>
                                    </tr>
                                    <tr  class="td-Berat_lahir">
                                        <th class="title"> Berat Lahir: </th>
                                        <td class="value"> <?php echo $data['Berat_lahir']; ?></td>
                                    </tr>
                                    <tr  class="td-panjang_badan">
                                        <th class="title"> Panjang Badan: </th>
                                        <td class="value"> <?php echo $data['panjang_badan']; ?></td>
                                    </tr>
                                    <tr  class="td-nama_bayi">
                                        <th class="title"> Nama Bayi: </th>
                                        <td class="value"> <?php echo $data['nama_bayi']; ?></td>
                                    </tr>
                                    <tr  class="td-nama_ibu">
                                        <th class="title"> Nama Ibu: </th>
                                        <td class="value"> <?php echo $data['nama_ibu']; ?></td>
                                    </tr>
                                    <tr  class="td-umur_ibu">
                                        <th class="title"> Umur Ibu: </th>
                                        <td class="value"> <?php echo $data['umur_ibu']; ?></td>
                                    </tr>
                                    <tr  class="td-pekerjaan_ibu">
                                        <th class="title"> Pekerjaan Ibu: </th>
                                        <td class="value"> <?php echo $data['pekerjaan_ibu']; ?></td>
                                    </tr>
                                    <tr  class="td-nik_ibu">
                                        <th class="title"> Nik Ibu: </th>
                                        <td class="value"> <?php echo $data['nik_ibu']; ?></td>
                                    </tr>
                                    <tr  class="td-alamat_ibu">
                                        <th class="title"> Alamat Ibu: </th>
                                        <td class="value"> <?php echo $data['alamat_ibu']; ?></td>
                                    </tr>
                                    <tr  class="td-nama_ayah">
                                        <th class="title"> Nama Ayah: </th>
                                        <td class="value"> <?php echo $data['nama_ayah']; ?></td>
                                    </tr>
                                    <tr  class="td-umur_ayah">
                                        <th class="title"> Umur Ayah: </th>
                                        <td class="value"> <?php echo $data['umur_ayah']; ?></td>
                                    </tr>
                                    <tr  class="td-pekerjaan_ayah">
                                        <th class="title"> Pekerjaan Ayah: </th>
                                        <td class="value"> <?php echo $data['pekerjaan_ayah']; ?></td>
                                    </tr>
                                    <tr  class="td-nik_ayah">
                                        <th class="title"> Nik Ayah: </th>
                                        <td class="value"> <?php echo $data['nik_ayah']; ?></td>
                                    </tr>
                                    <tr  class="td-alamat_ayah">
                                        <th class="title"> Alamat Ayah: </th>
                                        <td class="value"> <?php echo $data['alamat_ayah']; ?></td>
                                    </tr>
                                    <tr  class="td-operator">
                                        <th class="title"> Operator: </th>
                                        <td class="value"> <?php echo $data['operator']; ?></td>
                                    </tr>
                                    <tr  class="td-date_created">
                                        <th class="title"> Date Created: </th>
                                        <td class="value"> <?php echo $data['date_created']; ?></td>
                                    </tr>
                                </tbody>
                                <!-- Table Body End -->
                            </table>
                        </div>
                        <div class="p-3 d-flex">
                            <?php if($can_edit){ ?>
                            <a class="btn btn-sm btn-info"  href="<?php print_link("data_kelahiran/edit/$rec_id"); ?>">
                                <i class="fa fa-edit"></i> Edit
                            </a>
                            <?php } ?>
                        </div>
                        <?php
                        }
                        else{
                        ?>
                        <!-- Empty Record Message -->
                        <div class="text-muted p-3">
                            <i class="fa fa-ban"></i> No Record Found
                        </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
